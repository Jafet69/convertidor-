from flask import Flask, request, render_template, send_file
from pdf2docx import Converter
from PyPDF2 import PdfMerger
import os

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'pdf_file' in request.files:
            pdf_file = request.files['pdf_file']
            
            if pdf_file.filename == '' or not pdf_file.filename.endswith('.pdf'):
                return "Por favor, selecciona un archivo PDF válido."

            # Guardar el archivo PDF temporalmente
            pdf_path = os.path.join('uploads', pdf_file.filename)
            pdf_file.save(pdf_path)

            # Convertir el PDF a DOCX
            docx_path = os.path.join('uploads', pdf_file.filename.replace('.pdf', '.docx'))
            cv = Converter(pdf_path)
            cv.convert(docx_path)
            cv.close()

            # Enviar el archivo DOCX como respuesta
            return send_file(docx_path, as_attachment=True)
        
        elif 'pdf_files' in request.files:
            pdf_files = request.files.getlist('pdf_files')

            # Validar archivos PDF
            for pdf_file in pdf_files:
                if pdf_file.filename == '' or not pdf_file.filename.endswith('.pdf'):
                    return "Por favor, selecciona archivos PDF válidos."

            # Guardar archivos PDF temporalmente
            pdf_paths = []
            for pdf_file in pdf_files:
                pdf_path = os.path.join('uploads', pdf_file.filename)
                pdf_file.save(pdf_path)
                pdf_paths.append(pdf_path)

            # Fusionar PDFs
            merged_pdf_path = os.path.join('uploads', 'merged.pdf')
            merger = PdfMerger()
            for pdf_path in pdf_paths:
                merger.append(pdf_path)
            merger.write(merged_pdf_path)
            merger.close()

            # Enviar el PDF fusionado como respuesta
            return send_file(merged_pdf_path, as_attachment=True)

    return render_template('index.html')

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    app.run(debug=True)